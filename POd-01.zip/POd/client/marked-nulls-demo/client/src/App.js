import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Introduction from './components/Introduction';
import Workspace from './components/Workspace';

function App() {
  return (
    <Router>
      <div>
        <Routes>
          <Route path="/" element={<React.Fragment><Introduction /></React.Fragment>} />
          <Route path="/workspace" element={<React.Fragment><Workspace /></React.Fragment>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;