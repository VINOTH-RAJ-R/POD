select * from i1, i2 where i1.a = i2.a;
select * from d1, d2 where d1.a = d2.a;
select * from t1, t2 where t1.a = t2.a;
select * from n1, n2 where n1.a = n2.a;
