select avg(a), avg(b) from i1;
select avg(a), avg(b) from i1;
select avg(a), avg(b) from n1;
select avg(a), avg(b) from n1;