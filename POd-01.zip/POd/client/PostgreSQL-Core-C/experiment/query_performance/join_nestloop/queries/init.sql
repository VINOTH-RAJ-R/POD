-- Place any initial queires here.

-- For example:
-- ANALYZE;
ANALYZE;
SET max_parallel_workers = 0;
SET max_parallel_workers_per_gather = 0;
SET enable_nestloop = on;
SET enable_mergejoin = off;
SET enable_hashjoin = off;
