


import React, { useEffect, useRef, useState } from 'react';
import { Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import 'xterm/css/xterm.css';
import LocalEchoController from 'local-echo';
import './TerminalPage.css';

const TableSchema = ({ tables }) => {
  return (
    <div className="table-schema">
      <h3>Table Schema</h3>
      {tables.map((table, index) => (
        <div key={index} className="table-item">
          <h4>{table.name}</h4>
          <ul>
            {table.columns.map((column, colIndex) => (
              <li key={colIndex}>
                {column.name} ({column.type})
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};


const tablesData = [
  {
    name: "Employees",
    columns: [
      { name: "name", type: "varchar" },
      { name: "department", type: "varchar" },
      { name: "salary", type: "numeric" },
      { name: "phone_number", type: "varchar" },
      { name: "emergency_contact", type: "varchar" }
    ]
  }
];

const TerminalPage = ({ onSurveyClick }) => {
  const terminalRef = useRef(null);
  const terminal = useRef(null);
  const fitAddon = useRef(null);
  const localEcho = useRef(null);
  const [tables, setTables] = useState([]);

  useEffect(() => {
    // Initialize xterm.js
    terminal.current = new Terminal();
    fitAddon.current = new FitAddon();
    terminal.current.loadAddon(fitAddon.current);
    terminal.current.open(terminalRef.current);
    fitAddon.current.fit();

    // Initialize local-echo
    localEcho.current = new LocalEchoController();
    terminal.current.loadAddon(localEcho.current);

    // Display welcome message
    terminal.current.writeln('Welcome to the CLI-based environment for testing Marked Nulls in PostgreSQL!');
    terminal.current.writeln('Enter your SQL queries below and press Enter to execute.');
    terminal.current.writeln('Type "clear" to clear the terminal output.');
    terminal.current.writeln('Click "Let\'s go to the questionnaire" to proceed to the survey.');
    terminal.current.writeln('');

    // Set up WebSocket connection
    const socket = new WebSocket('ws://localhost:8080');

    socket.onopen = () => {
      terminal.current.writeln('WebSocket connection established.');
    };

    socket.onmessage = (event) => {
      terminal.current.write(event.data);
    };

    socket.onclose = () => {
      terminal.current.writeln('WebSocket connection closed.');
    };

    // Handle user input
    terminal.current.onData(data => {
      socket.send(data);
    });

    // Cleanup on component unmount
    return () => {
      terminal.current.dispose();
      socket.close();
    };
  }, []);

  const handleSurveyClick = () => {
    window.open('https://edinburghinformatics.eu.qualtrics.com/jfe/form/SV_2b0lahmcUS2Db0i', '_blank');
  };

  return (
    <div className="terminal-page">
      <div className="terminal-container">
        <div className="terminal-wrapper" ref={terminalRef}></div>
        <TableSchema tables={tablesData} />
      </div>
      <div className="survey-container">
        <button className="survey-button" onClick={handleSurveyClick}>
          Let's go to the questionnaire
        </button>
      </div>
    </div>
  );
};

export default TerminalPage;

