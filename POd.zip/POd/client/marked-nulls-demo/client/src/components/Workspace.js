import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import './Workspace.css';
import TerminalPage from './TerminalPage';

const Workspace = () => {
  const [query, setQuery] = useState('');
  const [queryResult, setQueryResult] = useState(null);
  const [tables, setTables] = useState([]);
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const env = searchParams.get('env');

  useEffect(() => {
    if (env !== 'cli') {
      fetchTableSchema();
    }
  }, [env]);

  const fetchTableSchema = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/table-schema');
      if (!response.ok) {
        throw new Error('Failed to fetch table schema');
      }
      const data = await response.json();
      const transformedData = data.reduce((acc, row) => {
        const { table_name, column_name, data_type } = row;
        const table = acc.find((t) => t.name === table_name);
        if (table) {
          table.columns.push({ name: column_name, type: data_type });
        } else {
          acc.push({ name: table_name, columns: [{ name: column_name, type: data_type }] });
        }
        return acc;
      }, []);
      setTables(transformedData);
    } catch (error) {
      console.error('Error fetching table schema:', error);
    }
  };

  const handleQueryChange = (e) => {
    setQuery(e.target.value);
  };

  const handleExecuteQuery = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/execute-query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query }),
      });
      if (!response.ok) {
        throw new Error('Failed to execute query');
      }
      const data = await response.json();
      if (data.command === 'INSERT' || data.command === 'UPDATE' || data.command === 'DELETE') {
        setQueryResult({ message: `Query executed successfully. Rows affected: ${data.rowCount}` });
      } else if (Array.isArray(data)) {
        const allColumns = new Set();
        data.forEach((row) => {
          Object.keys(row).forEach((column) => allColumns.add(column));
        });

        const transformedResult = data.map((row) => {
        const transformedRow = {};
        allColumns.forEach((column) => {
        transformedRow[column] = row[column] || null;
        });
        return transformedRow;
        });
        setQueryResult(transformedResult);
      } else {
        setQueryResult({ message: data.message });
      }

      if (data.command === 'CREATE' || data.command === 'DROP' || data.command === 'ALTER') {
        fetchTableSchema();
      }
    } catch (error) {
      console.error('Error executing query:', error);
      setQueryResult({ error: 'An error occurred while executing the query.' });
    }
  };

  /*const handleSurveyClick = () => {
    navigate('/survey');
  };*/
  const handleSurveyClick = () => {
    window.open('https://edinburghinformatics.eu.qualtrics.com/jfe/form/SV_2b0lahmcUS2Db0i', '_blank');
  };


  if (env === 'cli') {
    return <TerminalPage onSurveyClick={handleSurveyClick} />;
  }

  return (
    <div className="workspace">
      <div className="workspace-container">
        <div className="workspace-content">
          <div className="table-list">
            <h3>Tables</h3>
            {tables.map((table, index) => (
              <div className="table-item" key={index}>
                <h4>{table.name}</h4>
                <ul>
                  {table.columns.map((column, colIndex) => (
                    <li key={colIndex}>
                      {column.name} ({column.type})
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="query-section">
            <div className="query-input-container">
              <textarea
                className="query-input"
                value={query}
                onChange={handleQueryChange}
                placeholder="Enter your query..."
              />
              <button className="execute-button" onClick={handleExecuteQuery}>
                Execute
              </button>
            </div>
            <div className="query-result-container">
              {queryResult && (
                <>
                  {queryResult.message && <p className="success-message">{queryResult.message}</p>}
                  {queryResult.error && <p className="error-message">{queryResult.error}</p>}
                  {Array.isArray(queryResult) && (
                    queryResult.length > 0 ? (
                    <table className="query-result">
                    <thead>
                      <tr>
                    {Object.keys(queryResult[0]).map((header, index) => (
                      <th key={index}>{header}</th>
                    ))}
                      </tr>
                    </thead>
                    <tbody>
                      {queryResult.map((row, rowIndex) => (
                        <tr key={rowIndex}>
                          {Object.values(row).map((cell, cellIndex) => (
                            <td key={cellIndex}>{cell !== null ? cell : 'null'}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <p className="no-data-message">No data found</p>
                )
              )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
      <button className="survey-button" onClick={handleSurveyClick}>
        Let's go to the questionnaire
      </button>
    </div>
  );
};

export default Workspace;