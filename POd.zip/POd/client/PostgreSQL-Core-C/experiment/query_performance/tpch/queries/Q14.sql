SELECT 100.00 * sum(case
                        when p_type like 'PROMO%'::text
                            then (l_extendedprice * (1::numeric - l_discount))::numeric
                        else 0
    end) / sum(l_extendedprice * (1::numeric - l_discount)) as promo_revenue
FROM lineitem,
     part
WHERE l_partkey = p_partkey
  AND l_shipdate >= date '1995-09-01'
  AND l_shipdate < (date '1995-09-01' + interval '1' month)::date;
