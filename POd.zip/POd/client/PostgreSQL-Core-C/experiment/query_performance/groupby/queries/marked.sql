select a from i1 group by a;
select a from d1 group by a;
select a from t1 group by a;
select a from n1 group by a;
