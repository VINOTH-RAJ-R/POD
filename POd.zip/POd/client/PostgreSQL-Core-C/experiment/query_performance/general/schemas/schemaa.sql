CREATE TABLE i1 (
    a INTT,
    b INTT 
);
CREATE TABLE t1 (
    a TEXTT,
    b TEXTT
);
CREATE TABLE d1 (
    a DATEE,
    b DATEE
);
CREATE TABLE n1 (
    a NUMERICC,
    b NUMERICC
);
CREATE TABLE i2 (
    a INTT,
    b INTT 
);
CREATE TABLE t2 (
    a TEXTT,
    b TEXTT
);
CREATE TABLE d2 (
    a DATEE,
    b DATEE
);
CREATE TABLE n2 (
    a NUMERICC,
    b NUMERICC
);