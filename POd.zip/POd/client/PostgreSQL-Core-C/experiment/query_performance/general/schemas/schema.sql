CREATE TABLE i1 (
    a INT,
    b INT 
);
CREATE TABLE t1 (
    a TEXT,
    b TEXT
);
CREATE TABLE d1 (
    a DATE,
    b DATE
);
CREATE TABLE n1 (
    a NUMERIC,
    b NUMERIC
);
CREATE TABLE i2 (
    a INT,
    b INT 
);
CREATE TABLE t2 (
    a TEXT,
    b TEXT
);
CREATE TABLE d2 (
    a DATE,
    b DATE
);
CREATE TABLE n2 (
    a NUMERIC,
    b NUMERIC
);